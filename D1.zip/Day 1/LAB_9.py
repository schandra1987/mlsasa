from nltk.corpus import gutenberg


for filename in gutenberg.fileids():
    r = gutenberg.raw(filename)
    w = gutenberg.words(filename)
    s = gutenberg.sents(filename)
    v = set(w)
    print filename, len(r)/len(w), len(w)/len(s), len(w)/len(v)