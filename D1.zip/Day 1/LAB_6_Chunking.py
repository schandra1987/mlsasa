import nltk
from nltk import sent_tokenize, word_tokenize,pos_tag

input_sentence = ""
while input_sentence != "exit":
    input_sentence = raw_input("Enter the sentence : ")


    # split each sentence into words
    tokenized_sentence = word_tokenize(input_sentence)

    # tag each word with the pos tag
    tagged_sentence = pos_tag(tokenized_sentence)
    print "\nPOS tags : ", tagged_sentence


    grammar = r"""
                NP: {<DT|PP\$>?<JJ>*<NN>}   # chunk determiner/possessive, adjectives and noun
                {<NNP>+}                # chunk sequences of proper nouns
            """
    cp = nltk.RegexpParser(grammar)
    print cp.parse(tagged_sentence)






