import string
from nltk.corpus import wordnet as wn  # change made



def morphy_sentence(question):
    """
    It will take input text and will morphy the text
    :param question: String
    :return: String with morphied data
    """
    final_sentence = ""

    for word in question.split():
        if len(word) > 3:
            morphied = wn.morphy(word, pos='v')
            if morphied is None:
                morphied = wn.morphy(word, pos='n')
                if morphied is None:
                    final_sentence += word + " "
                else:
                    final_sentence += morphied + " "
            else:
                final_sentence += morphied + " "
        else:
            final_sentence += word + " "
    return final_sentence.strip()

print morphy_sentence("birds were flying in the sky.")