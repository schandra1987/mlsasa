from nltk import sent_tokenize, word_tokenize,pos_tag

input_sentence = ""
while input_sentence != "exit":
    input_sentence = raw_input("Enter the sentence : ")

    # split into multiple sentences.
    sentences = sent_tokenize(input_sentence)
    print "\nsentences are : "
    for line in sentences:
        print line

    # split each sentence into words
    tokenized_sentences = [word_tokenize(sentence) for sentence in sentences]
    print "\nwords in each sentence : "
    for line in tokenized_sentences:
        print line
