from nltk import sent_tokenize, word_tokenize,pos_tag

input_sentence = ""

while input_sentence != "exit":
    input_sentence = raw_input("Enter the sentence : ")
    
    # split into multiple sentences.
    sentences = sent_tokenize(input_sentence)
    
    for line in sentences:
        print "\nsentences are : "
        print line
