import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB

X_train = np.array(["what a lovely day!",
                    "the movie was criticised by many",
                    "i am hungry",
                    "i am happy that you came to the party",
                    "I do not like this car.",
                    "There is a book on the desk.",
                    "He is my enemy.",
                    "This view is amazing.",
                    " Childhood is the time to play."])

y_train = [1, -1, 0, 1, -1, 0, -1, 1, 0]

X_test = np.array(["I got an amazing book",
                   "I want to sleep",
                   "I do not feel like working"])

classifier = Pipeline([('vectorizer', TfidfVectorizer()),('clf', MultinomialNB())])


classifier.fit(X_train, y_train)
predicted = classifier.predict(X_test)

predicted_list = predicted.tolist()
X_test_list = X_test.tolist()
reverse_map_dict = { "1" :"Positive", "-1" : "Negative", "0" : "Neutral"}
for i , item in enumerate(predicted_list):
    print X_test_list[i] + " is " + reverse_map_dict[str(item)]

