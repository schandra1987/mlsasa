from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

corpus = [
    'I want to withdraw my provident fund.',
    'I want to learn english',
    'I think i need some water',
    'I know how to transfer fund',
]

vectorizer = CountVectorizer()

X = vectorizer.fit_transform(corpus)

vocab = vectorizer.get_feature_names()
array_ = X.toarray()

print vocab
print array_


